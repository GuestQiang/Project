//lottery.c
#define MAX_ROW 7
#define MAX_COL
//#include "lottery.h"

//首页显示
int HomeMenu()
{
    system("clear");
    printf("test5.8");
    putchar('\n');
    printf("\t\t\t  %s---------抽签系统---------%s\n","\e[42m","\e[0m");
    printf("\t\t\t  |                        |\n");
    printf("\t\t\t  |         1.成员         |\n");
    printf("\t\t\t  |                        |\n");
    printf("\t\t\t  |         2.抽签         |\n");
    printf("\t\t\t  |                        |\n");
    printf("\t\t\t  |         3.退出         |\n");
    printf("\t\t\t  |                        |\n");
    printf("\t\t\t  --------------------------\n");
    putchar('\n');
    printf("Select>");
    int sel;
    
    scanf("%d",&sel);
    getchar();

    return sel;
}

//初始化结构体数据
int Inti(struct AllInfo *p)
{
    FILE *pf =fopen("./data.txt","r");
    char name[10];
    p->size=0;
    
    for(int i=0; fscanf(pf,"%s %d %d",
		p->data[i].stuname,
		&p->data[i].row,
		&p->data[i].col) != EOF; i++)
    {
	p->data[i].bingo = 0;
	p->size++;
    }
    strcpy(p->bgcolor[0],"\e[0m");
    strcpy(p->bgcolor[1],"\e[42m");
    fclose(pf);
}

/*
//测试函数 显示所有数据
void test(struct AllInfo *p)
{
    for(int i=0; i<p->size; i++)
    {
	printf("name:%s row:%d col:%d bingo:%d\n",
		p->data[i].stuname,
		p->data[i].row,
		p->data[i].col,
		p->data[i].bingo);
    }
}
*/

//显示班级分布图

int ShowAll(struct AllInfo *p)
{
    system("clear");
    int ROW,COL,i,k;
    int max =56;

    printf("\t                                        <  >                              \n");
    printf("\t    -----------------------------------------------------------------------------\n");
    printf("\t    |                                                                           |\n");

    //遍历所有座位
    for (i=0; i<max; i++)
    {
	ROW=i/8;
	COL=i%8;
       
	//如果为第一列
	if(COL==0)
	    printf("\t    |");
	
	
	for(k=0; k<max; k++)
	{

	    //如果符合行列 输出 中断本次循环
	    if(p->data[k].row==ROW && p->data[k].col==COL)
	    {
		printf("   %s%6s\e[0m",p->bgcolor[p->data[k].bingo],
			p->data[k].stuname);
		break;
	    }
	}

	//如果未终端内部循环说明不存在符合座位行列信息的学员，*填充
	//                                 ??????????????????????
	if(k==max)
	    printf(" %6s  ","*");

	//如果行号为7则换行
	if(COL==7)
	{
	    printf("   |\n");
	    printf("\t    |                                                                           |\n");
	}
	
    }
    printf("\t    -----------------------------------------------------------------------------\n");

}
    

//定义抽签函数->取随机值
int LotExe(struct AllInfo *p)
{
    int luck;
    srand((unsigned int)time(NULL));
    luck=rand()%p->size;
    p->data[luck].bingo=1;
    return luck;
}

//定义抽签显示函数->显示抽签过程
int ExeShow(int (*lot)(struct AllInfo *),int (*show)(struct AllInfo *) ,struct AllInfo *p)
{
    system("clear");
    int i,recover,luck,arr[1000];
    printf("\t\t\t        按下任意键开始！\n");
    getchar();
    /*方法1
    for (i=1; i<10; i++)
    {
	//system("clear");
	recover=lot(p);
	show(p);
	printf("\t\t\t\t\t     > %s\n",p->data[recover].stuname);
	p->data[recover].bingo=0;
	usleep(1000000);
    }
    */

    srand((unsigned int)time(NULL));
    for(i=0; i<1000; i++)
    {
    	luck=rand()%p->size;
    	arr[i]=luck;
    }
    
    for(recover=0; recover<80; recover++)
    {
	p->data[arr[recover]].bingo=1;
	show(p);
	printf("\t\t\t\t\t     > %s\n",p->data[arr[recover]].stuname);
	//printf("%d\n",arr[recover]);
	p->data[arr[recover]].bingo=0;
	usleep(90000);
    }
    return 0;



}

//定义流程控制函数->函数结束后选择下一步操作

int Flow()
{
    int sel;
    //printf("\t    -----------------------------------------------------------------------------\n");
    printf("\n");
    printf("\t                      1.首页           2.抽签          3.退出系统               \n");

    printf("Select>");
    scanf("%d",&sel);
    getchar();

    return sel;
}







