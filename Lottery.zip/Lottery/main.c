//main.c
#include <stdlib.h>
#include <time.h>
#include "lottery.h"
#include "lottery.c"

int main()
{
    LotMain();

    return 0;
}

int LotMain()
{
    //创建操作对象Lot
    struct AllInfo Lot;
    
    //创建主结构控制变量sel
    int sel=1,sel_control=0;

    do
    {
    	sel = HomeMenu();
    	//printf("Select>");
    	//scanf("%d",&sel);
    	//getchar();

    	Inti(&Lot);
    	//test(&Lot);
	
	do
	{
	    switch(sel)
	    {
		case 1:
	   	 	ShowAll(&Lot);
	    		sel_control=Flow();
			if(sel_control==3)
			    return 0;
			else if(sel_control==1)
			    sel_control=0;	   
			else if(sel_control==2)
			    sel=2;	
			break;

		case 2:
	    		ExeShow(LotExe,ShowAll,&Lot);
	    		sel_control=Flow();
			if(sel_control==3)
			    return 0;
			else if(sel_control==1)
			    sel_control=0;
			    
			else if(sel_control==2)
			    sel=2;
			break;

		case 3:
			return 0;
	    }

	}while(sel_control);
    
    }while(sel);
  
}

