//lottery.h
#define NAME 20
#include <stdio.h>
#include <string.h>

struct StuInfo
{
    int stuname[NAME];
    int row;
    int col;
    int bingo;
};

struct AllInfo
{
    struct StuInfo data[1024];
    int size;
    char bgcolor[2][10];
};

int HomeMenu();
int Inti(struct AllInfo *p);
//void test(struct AllInfo *p);
int ShowAll(struct AllInfo *p);
int LotExe(struct AllInfo *p);
int ExeShow(int (*lot)(struct AllInfo *),int (*show)(struct AllInfo *),struct AllInfo *p);
int Flow();
